create definer = root@localhost view v_nameandphone as
select `classicmodels`.`customers`.`customerName` AS `customerName`, `classicmodels`.`customers`.`phone` AS `phone`
from `classicmodels`.`customers`;


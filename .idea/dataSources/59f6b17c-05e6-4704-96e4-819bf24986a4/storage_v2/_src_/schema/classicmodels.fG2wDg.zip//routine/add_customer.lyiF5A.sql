create
    definer = root@localhost procedure add_customer(IN id int, IN name varchar(255), IN lastName varchar(255),
                                                    IN firstName varchar(255), IN phone varchar(255),
                                                    IN add1 varchar(255), IN add2 varchar(255), IN city varchar(50),
                                                    IN state varchar(50), IN code varchar(15), IN country varchar(50),
                                                    IN saleNumber int, IN credit decimal)
begin
    insert into customers (customerNumber, customerName, contactLastName, contactFirstName, phone, addressLine1, addressLine2, city, state, postalCode, country, salesRepEmployeeNumber, creditLimit) VALUES (id, name, firstName, lastName,phone, add1, add2, city, state, code, country, saleNumber, credit);
end;

